import 'package:flutter/material.dart';

void main() => runApp(const MeraGaonApp());

const green = Color(0xFF16834A);
const darkGreen = Color(0xFF0D5D35);
const paleGreen = Color(0xFFEAF6EE);

class MeraGaonApp extends StatelessWidget {
  const MeraGaonApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MERA GAON',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: green, brightness: Brightness.light),
        scaffoldBackgroundColor: const Color(0xFFF7FAF7),
        appBarTheme: const AppBarTheme(backgroundColor: Colors.white, foregroundColor: darkGreen),
        inputDecorationTheme: InputDecorationTheme(
          filled: true, fillColor: Colors.white,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: Color(0xFFDCE9DF))),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: Color(0xFFDCE9DF))),
        ),
      ),
      home: const MainShell(),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;
  final List<Map<String, String>> pendingPosts = [];

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(onNavigate: (i) => setState(() => index = i)),
      const NewsPage(),
      const MarketPage(),
      const JobsPage(),
      ProfilePage(pendingCount: pendingPosts.length),
    ];
    return Scaffold(
      body: SafeArea(child: pages[index]),
      floatingActionButton: index == 0 || index == 1
          ? FloatingActionButton.extended(
              backgroundColor: green, foregroundColor: Colors.white,
              onPressed: () async {
                final post = await Navigator.push<Map<String, String>>(
                  context, MaterialPageRoute(builder: (_) => const CreatePostPage()));
                if (post != null) setState(() => pendingPosts.add(post));
              },
              icon: const Icon(Icons.add), label: const Text('पोस्ट करें'))
          : null,
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (v) => setState(() => index = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'होम'),
          NavigationDestination(icon: Icon(Icons.newspaper_outlined), label: 'खबरें'),
          NavigationDestination(icon: Icon(Icons.storefront_outlined), label: 'बाजार'),
          NavigationDestination(icon: Icon(Icons.work_outline), label: 'नौकरी'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'प्रोफाइल'),
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  final ValueChanged<int> onNavigate;
  const HomePage({super.key, required this.onNavigate});

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.fromLTRB(18, 12, 18, 90), children: [
      Row(children: [
        Container(width: 46, height: 46, decoration: BoxDecoration(color: paleGreen, borderRadius: BorderRadius.circular(15)),
          child: const Icon(Icons.grass, color: green, size: 29)),
        const SizedBox(width: 10),
        const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('MERA GAON', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: darkGreen, letterSpacing: .5)),
          Text('अपना गाँव, अपनी पहचान', style: TextStyle(color: Colors.black54, fontSize: 12)),
        ])),
        IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none, color: darkGreen)),
      ]),
      const SizedBox(height: 18),
      Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [green, darkGreen]),
        borderRadius: BorderRadius.circular(22)),
        child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('नमस्ते! आपका स्वागत है 👋', style: TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.bold)),
          SizedBox(height: 6),
          Text('बस्तर की खबरें, काम और बाजार — सब एक जगह।', style: TextStyle(color: Colors.white, height: 1.4)),
          SizedBox(height: 14),
          Row(children: [Icon(Icons.location_on, color: Colors.white70, size: 17), SizedBox(width: 4), Text('बस्तर, छत्तीसगढ़', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600))])
        ])),
      const SizedBox(height: 22),
      const SectionTitle('आपके लिए सेवाएँ'),
      const SizedBox(height: 12),
      GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 1.55,
        children: [
          ServiceTile(icon: Icons.newspaper, title: 'गाँव की खबरें', subtitle: 'स्थानीय अपडेट', onTap: () => onNavigate(1)),
          ServiceTile(icon: Icons.storefront, title: 'गाँव का बाजार', subtitle: 'खरीदें और बेचें', onTap: () => onNavigate(2)),
          ServiceTile(icon: Icons.work, title: 'नौकरी और काम', subtitle: 'रोजगार खोजें', onTap: () => onNavigate(3)),
          ServiceTile(icon: Icons.campaign, title: 'जरूरी सूचना', subtitle: 'घोषणाएँ और कार्यक्रम', onTap: () => onNavigate(1)),
        ]),
      const SizedBox(height: 22),
      const SectionTitle('ताज़ा अपडेट'),
      const SizedBox(height: 10),
      const InfoCard(icon: Icons.info_outline, title: 'MERA GAON में आपका स्वागत है', body: 'यह शुरुआती डेमो ऐप है। वास्तविक खबरें और पोस्ट Admin की जाँच के बाद जोड़ी जाएँगी।'),
      const SizedBox(height: 8),
      const InfoCard(icon: Icons.verified_user_outlined, title: 'सुरक्षित पोस्टिंग', body: 'आपकी भेजी हुई पोस्ट पहले समीक्षा के लिए जाएगी। मंजूरी मिलने के बाद ही सार्वजनिक होगी।'),
    ]);
  }
}

class SectionTitle extends StatelessWidget {
  final String title;
  const SectionTitle(this.title, {super.key});
  @override
  Widget build(BuildContext context) => Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: darkGreen));
}

class ServiceTile extends StatelessWidget {
  final IconData icon; final String title; final String subtitle; final VoidCallback onTap;
  const ServiceTile({super.key, required this.icon, required this.title, required this.subtitle, required this.onTap});
  @override
  Widget build(BuildContext context) => InkWell(onTap: onTap, borderRadius: BorderRadius.circular(18),
    child: Container(padding: const EdgeInsets.all(13), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFFE2EDE5))),
      child: Row(children: [
        Container(width: 40, height: 40, decoration: BoxDecoration(color: paleGreen, borderRadius: BorderRadius.circular(12)), child: Icon(icon, color: green)),
        const SizedBox(width: 9),
        Expanded(child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: darkGreen)),
          const SizedBox(height: 3), Text(subtitle, style: const TextStyle(fontSize: 10, color: Colors.black54))
        ]))
      ])));
}

class InfoCard extends StatelessWidget {
  final IconData icon; final String title; final String body;
  const InfoCard({super.key, required this.icon, required this.title, required this.body});
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFFE4ECE6))),
    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, color: green), const SizedBox(width: 10),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 4),
        Text(body, style: const TextStyle(color: Colors.black54, height: 1.4, fontSize: 12))
      ]))
    ]));
}

class NewsPage extends StatelessWidget {
  const NewsPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: const [
    PageHeading(title: 'गाँव की खबरें', subtitle: 'बस्तर और आसपास की स्थानीय जानकारी'),
    SizedBox(height: 14),
    InfoCard(icon: Icons.newspaper, title: 'अभी कोई प्रकाशित खबर नहीं', body: 'नई खबरें Admin द्वारा जाँच और मंजूरी के बाद यहाँ दिखाई देंगी।'),
  ]);
}

class MarketPage extends StatelessWidget {
  const MarketPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: const [
    PageHeading(title: 'गाँव का बाजार', subtitle: 'स्थानीय सामान और सेवाएँ'),
    SizedBox(height: 14),
    InfoCard(icon: Icons.storefront, title: 'बाजार जल्द शुरू होगा', body: 'विक्रेता अपनी वस्तुओं की जानकारी और कीमत पोस्ट कर सकेंगे। खरीद-बिक्री से पहले सामान और विक्रेता की जाँच करें।'),
  ]);
}

class JobsPage extends StatelessWidget {
  const JobsPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: const [
    PageHeading(title: 'नौकरी और काम', subtitle: 'स्थानीय रोजगार के अवसर'),
    SizedBox(height: 14),
    InfoCard(icon: Icons.work_outline, title: 'अभी कोई नौकरी उपलब्ध नहीं', body: 'नौकरी की जानकारी सत्यापित होने के बाद यहाँ दिखाई जाएगी। नौकरी पाने के लिए किसी को पहले पैसे न दें।'),
  ]);
}

class PageHeading extends StatelessWidget {
  final String title; final String subtitle;
  const PageHeading({super.key, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: darkGreen)),
    const SizedBox(height: 4), Text(subtitle, style: const TextStyle(color: Colors.black54))
  ]);
}

class ProfilePage extends StatelessWidget {
  final int pendingCount;
  const ProfilePage({super.key, required this.pendingCount});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    const PageHeading(title: 'आपकी प्रोफाइल', subtitle: 'MERA GAON पर आपका खाता'),
    const SizedBox(height: 20),
    const CircleAvatar(radius: 38, backgroundColor: paleGreen, child: Icon(Icons.person, size: 42, color: green)),
    const SizedBox(height: 10),
    const Center(child: Text('अतिथि यूजर', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18))),
    const Center(child: Text('डेमो मोड — Login अभी जोड़ा नहीं गया है', style: TextStyle(color: Colors.black54, fontSize: 12))),
    const SizedBox(height: 20),
    InfoCard(icon: Icons.pending_actions, title: 'आपकी समीक्षा वाली पोस्ट', body: '$pendingCount पोस्ट इस डेमो से भेजी गई हैं। असली सर्वर पर Admin approval जोड़ना बाकी है।'),
    const SizedBox(height: 10),
    ListTile(leading: const Icon(Icons.language, color: green), title: const Text('भाषा'), subtitle: const Text('भाषा चयन अगले चरण में जोड़ा जाएगा')),
    ListTile(leading: const Icon(Icons.login, color: green), title: const Text('Login'), subtitle: const Text('OTP और Google Login अगले चरण में जोड़े जाएँगे')),
  ]);
}

class CreatePostPage extends StatefulWidget {
  const CreatePostPage({super.key});
  @override
  State<CreatePostPage> createState() => _CreatePostPageState();
}

class _CreatePostPageState extends State<CreatePostPage> {
  final title = TextEditingController();
  final details = TextEditingController();
  String category = 'गाँव की खबर';
  @override
  void dispose() { title.dispose(); details.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('नई पोस्ट')),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      const Text('अपनी जानकारी भेजें', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: darkGreen)),
      const SizedBox(height: 6),
      const Text('डेमो में पोस्ट केवल इस फोन की स्क्रीन पर गिनी जाएगी। असली सार्वजनिक पोस्टिंग के लिए सर्वर और Admin approval जोड़ना होगा।', style: TextStyle(color: Colors.black54, height: 1.4)),
      const SizedBox(height: 18),
      DropdownButtonFormField<String>(value: category, decoration: const InputDecoration(labelText: 'पोस्ट का प्रकार'), items: const [
        DropdownMenuItem(value: 'गाँव की खबर', child: Text('गाँव की खबर')),
        DropdownMenuItem(value: 'नौकरी', child: Text('नौकरी')),
        DropdownMenuItem(value: 'बाजार', child: Text('बाजार')),
        DropdownMenuItem(value: 'कार्यक्रम / सूचना', child: Text('कार्यक्रम / सूचना')),
      ], onChanged: (v) => setState(() => category = v ?? category)),
      const SizedBox(height: 12),
      TextField(controller: title, decoration: const InputDecoration(labelText: 'शीर्षक', hintText: 'जैसे: गाँव में मेला आयोजित होगा')),
      const SizedBox(height: 12),
      TextField(controller: details, minLines: 4, maxLines: 7, decoration: const InputDecoration(labelText: 'पूरी जानकारी', hintText: 'यहाँ जानकारी लिखें...')),
      const SizedBox(height: 20),
      FilledButton.icon(
        style: FilledButton.styleFrom(backgroundColor: green, padding: const EdgeInsets.symmetric(vertical: 15)),
        onPressed: () {
          if (title.text.trim().isEmpty || details.text.trim().isEmpty) {
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('कृपया शीर्षक और जानकारी भरें।')));
            return;
          }
          Navigator.pop(context, {'category': category, 'title': title.text.trim(), 'details': details.text.trim(), 'status': 'pending'});
        },
        icon: const Icon(Icons.send), label: const Text('जाँच के लिए भेजें')),
    ]),
  );
}
